#!/bin/sh
EXTENSION=/mnt/us/extensions/gargoyle
cd ${EXTENSION}
lipc-set-prop -s com.lab126.keyboard open net.fabiszewski.gargoyle:abc:0
SAVED_GAMES=./saved_games/ \
GAMES=./games/ \
LD_LIBRARY_PATH=${EXTENSION}/lib \
PATH=$PATH:${EXTENSION}/bin \
./bin/gargoyle
lipc-set-prop -s com.lab126.keyboard close net.fabiszewski.gargoyle
